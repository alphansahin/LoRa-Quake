/*****************************************************************************************************
  Programs for LoRaQuake - Copyright of the author Alphan Sahin - 15/06/2023txrxEnable

  This program is supplied as is, it is up to the user of the program to decide if the program is
  suitable for the intended purpose and free from errors.
*******************************************************************************************************/
#include <SPI.h>
#include <Wire.h>
#include <U8x8lib.h> //https://github.com/olikraus/u8g2
#include <SX1280_alphan.h>
#include "settings.h"
#include <math.h>
#include <WiFi.h>


// GLOBAL VARIABLES
// varilables for devices/chips
U8X8_SSD1306_128X64_NONAME_HW_I2C disp(U8X8_PIN_NONE); // standard 0.96" SSD1306
SX128XLT LT;                                           // create a library class instance called LT

// Wi-Fi/server parameters
char ssid[] = "alphanLoRa";
char pass[] = "alphanLoRa";
const uint serverPort = SERVERPORTVAL;
WiFiServer server(serverPort);
WiFiClient client;
bool connected = false;
String responseString;
char responseCharArray[RESPONSE_LENGTH];
String messageToBeSent;
char messageToBeSentCharArray[MESSAGE_LENGTH];
char messageReceivedCharArray[MESSAGE_LENGTH];
bool aNewNessageAvailable = false;

// miscellaneous variables
uint8_t cntLoop = 0;
uint8_t indexGeneral;

// variables related to ranging
uint32_t rangingAddressMaster = 0, rangingAddressSlave = 0;
uint8_t rangingRole = 0;
double distanceRAW, distanceBIASED;
int32_t range_result;

// variables related to neighbours
neighbourStructure neighbours[MAXNUMBEROFNEIGBOURS];
uint8_t indicesNeighbours[MAXNUMBEROFNEIGBOURS];
uint8_t cntNeigbours = 0;
myInfoStructure myInfo;

// variables related to tx/rx packets
uint8_t stateTX = 0;
uint16_t addr;
uint8_t cmd;
uint8_t RXPacketL;               // stores length of packet received
uint8_t RXBUFFER[RXBUFFER_SIZE]; // create the buffer that received packets are copied into
uint8_t TXPacketL;
uint8_t TXBUFFER[TXBUFFER_SIZE];
uint16_t IRQStatus;
bool slotAvailibility[Nslot];

// variables related to timing
unsigned long Tstart;
unsigned long Tduration;
signed long Tremaining_us;
uint16_t Tremaining_calc_uint16;

/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
// LED display
void updateDisplay()
{
  // disp.clear();
  uint8_t indexCursor = 0;
  IPAddress ip = WiFi.localIP();
  disp.setCursor(0, indexCursor);
  disp.printf("IP:%d.%d.%d.%d", ip[0],ip[1],ip[2],ip[3]);
  indexCursor++;

  disp.setCursor(0, indexCursor);
  disp.printf("ID:%2d,S:%2d,%3d", myInfo.id,myInfo.slotIndex,cntLoop);
  indexCursor++;  

  const uint8_t dispOption=1;
  switch (dispOption)
  {
  case 1:
    disp.setCursor(0, indexCursor);
    disp.printf("ID|RSSI|Slot");
    indexCursor++;
    
    for (indexGeneral = 0; indexGeneral < MAXNUMBEROFNEIGBOURS; indexGeneral++)
    {
      if (neighbours[indexGeneral].id > 0)
      {
        disp.setCursor(0, indexCursor);
        disp.printf("%2d|%3d|%2d  ", neighbours[indexGeneral].id,  neighbours[indexGeneral].RSSI, neighbours[indexGeneral].slotIndex);
        indexCursor++;
      }
    }
    break;   
  
  default:
    break;
  }
  

  for (indexGeneral = indexCursor; indexGeneral < 8; indexGeneral++)
  {
    disp.setCursor(0, indexGeneral);
    disp.printf("                \n");
  }
}
void setupDevice()
{
  LT.setPeriodBase(periodBaseVar);
  LT.setMode(MODE_STDBY_RC);
  LT.setRegulatorMode(USE_LDO);
  LT.setRfFrequency(frequency, offset);
  LT.setModulationParams(spreadingFactor, bandwidth, codeRate);
  
  LT.setRangingCalibration(calibration); // override automatic lookup of calibration value from library table
  LT.setHighSensitivity();
}
void switchLoRa()
{
  //LT.setMode(MODE_STDBY_RC);
  // LT.setRegulatorMode(USE_LDO);
  LT.setPacketType(PACKET_TYPE_LORA);
  // LT.setRfFrequency(frequency, offset);
  LT.setBufferBaseAddress(0, 0);
  //LT.setModulationParams(spreadingFactor, bandwidth, codeRate);
  LT.setPacketParams(12, LORA_PACKET_VARIABLE_LENGTH, 255, LORA_CRC_ON, LORA_IQ_NORMAL, 0, 0);  
  LT.setDioIrqParams(IRQ_RADIO_ALL, (IRQ_TX_DONE + IRQ_RX_TX_TIMEOUT), 0, 0);
  LT.setHighSensitivity();
}

void doThings_TX_CMD_IDANDPOS()
{
  #ifdef VERBOSE
    printf("TX: ID and POS will be broadcast\n");
  #endif  
  TXBUFFER[0] = (uint8_t)((ADR_BROADCAST >> 8) & 0xFF);
  TXBUFFER[1] = (uint8_t)((ADR_BROADCAST) & 0xFF);
  TXBUFFER[2] = CMD_IDANDPOS;
  TXBUFFER[3] = (uint8_t)((myInfo.id >> 8) & 0xFF);
  TXBUFFER[4] = (uint8_t)((myInfo.id) & 0xFF);
  TXBUFFER[5] = myInfo.slotIndex;
  TXBUFFER[6] = (myInfo.isLocalized<<7) + myInfo.hoppingDistance;
  TXPacketL = 7;



  for (indexGeneral = 0; indexGeneral < cntNeigbours; indexGeneral++)
    {
      TXBUFFER[TXPacketL] = (uint8_t)((neighbours[indicesNeighbours[indexGeneral]].id >> 8) & 0xFF);
      TXBUFFER[TXPacketL+1] = (uint8_t)((neighbours[indicesNeighbours[indexGeneral]].id) & 0xFF);
      TXBUFFER[TXPacketL+2] = neighbours[indicesNeighbours[indexGeneral]].slotIndex;
      TXBUFFER[TXPacketL+3] = (neighbours[indicesNeighbours[indexGeneral]].isLocalized<<7) + neighbours[indicesNeighbours[indexGeneral]].hoppingDistance;
      TXPacketL = TXPacketL + 4;
    }

  switchLoRa();
  uint8_t lengthTX;
  lengthTX = LT.transmitIRQ(TXBUFFER, TXPacketL, communicationTimeoutTX, TXPower, WAIT_TX);

  #ifdef VERBOSE
    if (lengthTX > 0)
    {
      printf("TX: ID and POS are broadcast\n");
    }
    else
    {
      printf("TX: ID and POS couldnt be broadcast\n");
    }
  #endif
}
uint8_t doThings_RX_CMD_IDANDPOS()
{
  uint8_t indexNeighbourSelected;
  #ifdef VERBOSE
    printf("RX: ID command is received\n");
  #endif     

  
  for (indexGeneral = 0; indexGeneral < MAXNUMBEROFNEIGBOURS; indexGeneral++)
  {
    if (neighbours[indexGeneral].id == (RXBUFFER[3] << 8) + RXBUFFER[4]) // if it exists, take and update it.
    {
      indexNeighbourSelected = indexGeneral;
      break;
    }

    if (neighbours[indexGeneral].id == 0) // if an empty spot exists, take it.
    {
      indexNeighbourSelected = indexGeneral;
    }    
  }

  neighbours[indexNeighbourSelected].id = uint16_t((RXBUFFER[3] << 8) + RXBUFFER[4]);
  neighbours[indexNeighbourSelected].slotIndex = RXBUFFER[5];
  neighbours[indexNeighbourSelected].isLocalized = uint8_t((RXBUFFER[6] >> 7));
  neighbours[indexNeighbourSelected].hoppingDistance = RXBUFFER[6] & 0x7F;

  neighbours[indexNeighbourSelected].numberOfNeighbours = 0;
  uint8_t indexByte = 7;
  while (RXPacketL>indexByte){
    neighbours[indexNeighbourSelected].neighboursId[neighbours[indexNeighbourSelected].numberOfNeighbours] = uint16_t((RXBUFFER[indexByte] << 8) + RXBUFFER[indexByte+1]);
    neighbours[indexNeighbourSelected].neighboursSlot[neighbours[indexNeighbourSelected].numberOfNeighbours] = RXBUFFER[indexByte+2];
    neighbours[indexNeighbourSelected].neighboursIsLocalized[neighbours[indexNeighbourSelected].numberOfNeighbours] = uint8_t((RXBUFFER[indexByte+3] >> 7));
    neighbours[indexNeighbourSelected].neighboursHoppingDistance[neighbours[indexNeighbourSelected].numberOfNeighbours] = RXBUFFER[indexByte+3] & 0x7F;  
    // #ifdef VERBOSE
    //   printf("NN IDs: %d\n", neighbours[indexNeighbourSelected].neighboursId[neighbours[indexNeighbourSelected].numberOfNeighbours]);
    // #endif        
    neighbours[indexNeighbourSelected].numberOfNeighbours++;
    indexByte = indexByte + 4;
  }

  neighbours[indexNeighbourSelected].RSSI = LT.readPacketRSSI(); // read the received packets RSSI value
  neighbours[indexNeighbourSelected].SNR = LT.readPacketSNR();   // read the received packets SNR value
  neighbours[indexNeighbourSelected].activityCounter = MAXNUMBEROFINACTIVE;

  // Check if there exists any collision (with my neighbour)
    bool assignMeANewSlot = false;
  if (neighbours[indexNeighbourSelected].slotIndex == myInfo.slotIndex)
  {
    assignMeANewSlot = true;
  }

// Check if there exists any collision (with my neighbour's neighbour)
  for (indexGeneral = 0; indexGeneral < neighbours[indexGeneral].numberOfNeighbours; indexGeneral++)
  {
    if (neighbours[indexNeighbourSelected].neighboursSlot[indexGeneral] == myInfo.slotIndex)
    {
      assignMeANewSlot = true;
      break;
    }
  }

  // Check if I am listed as neighbour or not
  bool amIlistedAsNeighbour = false;
  #ifdef VERBOSE
    printf("Number of neigbours neighbours: %d\n", neighbours[indexNeighbourSelected].numberOfNeighbours);
  #endif 
  for (indexGeneral = 0; indexGeneral < neighbours[indexNeighbourSelected].numberOfNeighbours; indexGeneral++)
  {
    #ifdef VERBOSE
      printf("NN IDs: %d My id:%d \n", neighbours[indexNeighbourSelected].neighboursId[indexGeneral],  myInfo.id);
    #endif 
    if (neighbours[indexNeighbourSelected].neighboursId[indexGeneral] == myInfo.id)
    {
      amIlistedAsNeighbour = true;
      break;
    }
  }  

  neighbours[indexNeighbourSelected].amIListedAsNeigbour = amIlistedAsNeighbour;

  if (amIlistedAsNeighbour == false)
  {
    // assignMeANewSlot = true; %%%% An important decision
  }

  #ifdef VERBOSE
    printf("Am I listed as a neighbour?: %d\n", amIlistedAsNeighbour);
    printf("Assign me a new slot val: %d\n", assignMeANewSlot);
  #endif 

  if (assignMeANewSlot == true) // if there exists any collision, update the slot
  {
    // identify the available slots
    uint8_t numberOfAvailableSlots, slotCandidate;
    for (slotCandidate = 0; slotCandidate < Nslot; slotCandidate++)
    {
      slotAvailibility[slotCandidate] = true;
      if (neighbours[indexNeighbourSelected].slotIndex == slotCandidate)
      {
        slotAvailibility[slotCandidate] = false;
      }

      for (indexGeneral = 0; indexGeneral < neighbours[indexGeneral].numberOfNeighbours; indexGeneral++)
      {
        if (neighbours[indexNeighbourSelected].neighboursSlot[indexGeneral] == slotCandidate)
        {
          slotAvailibility[slotCandidate] = false;
          break;
        }
      }

      if (slotAvailibility[slotCandidate] == true)
      {
        //printf("available:%d\n", slotCandidate);
        numberOfAvailableSlots++;
      }
    }

    uint8_t indexChosen,cnt=0;
    indexChosen = random(0,numberOfAvailableSlots);

    //printf("Navailable:%d\n", numberOfAvailableSlots);

    uint8_t availableSlotsIndices[numberOfAvailableSlots];
    for (slotCandidate =  0; slotCandidate < Nslot; slotCandidate++)
    {
      if (slotAvailibility[slotCandidate] == true)
      {
        if (cnt == indexChosen)
          {
            #if (fixSlot == 1)
              myInfo.slotIndex = slotDevice;
            #else
              myInfo.slotIndex = slotCandidate;
            #endif
            //printf("Chosen slot:%d\n", slotCandidate);
            break;
          }
        cnt++;
        
      }
    }
  }

  return neighbours[indexNeighbourSelected].slotIndex;
}
void doThings_TX_CMD_MESSAGE(uint16_t add_tosent)
{
  #ifdef VERBOSE
    printf("TX: MESSAGE will be transmitted\n");
  #endif  
  TXBUFFER[0] = (uint8_t)((add_tosent >> 8) & 0xFF);
  TXBUFFER[1] = (uint8_t)((add_tosent) & 0xFF);
  TXBUFFER[2] = CMD_MESSAGE;
  TXBUFFER[3] = (uint8_t)((myInfo.id >> 8) & 0xFF);
  TXBUFFER[4] = (uint8_t)((myInfo.id) & 0xFF);
  TXBUFFER[5] = myInfo.slotIndex;
  TXBUFFER[6] = (myInfo.isLocalized<<7) + myInfo.hoppingDistance;
  TXPacketL = 7;

  messageToBeSent.toCharArray(messageToBeSentCharArray,MESSAGE_LENGTH);

  for (indexGeneral = 0; indexGeneral < MESSAGE_LENGTH; indexGeneral++)
    {
      TXBUFFER[TXPacketL] = (uint8_t)(messageToBeSentCharArray[indexGeneral]);
      TXPacketL = TXPacketL + 1;
      //printf("TX:%c\n",messageToBeSentCharArray[indexGeneral]);
    }

  switchLoRa();
  uint8_t lengthTX;
  lengthTX = LT.transmitIRQ(TXBUFFER, TXPacketL, communicationTimeoutTX, TXPower, WAIT_TX);
  messageToBeSent = "";
  aNewNessageAvailable = false;
  #ifdef VERBOSE
    if (lengthTX > 0)
    {
      printf("TX: MESSAGE is transmitted\n");
    }
    else
    {
      printf("TX: MESSAGE couldnt be transmitted\n");
    }
  #endif
}
uint8_t doThings_RX_CMD_MESSAGE()
{
  uint8_t indexNeighbourSelected;
  #ifdef VERBOSE
    printf("RX: MSG is received\n");
  #endif     

  // add to your neighbourlist
  for (indexGeneral = 0; indexGeneral < MAXNUMBEROFNEIGBOURS; indexGeneral++)
  {
    if (neighbours[indexGeneral].id == (RXBUFFER[3] << 8) + RXBUFFER[4]) // if it exists, take and update it.
    {
      indexNeighbourSelected = indexGeneral;
      break;
    }

    if (neighbours[indexGeneral].id == 0) // if an empty spot exists, take it.
    {
      indexNeighbourSelected = indexGeneral;
    }    
  }

  neighbours[indexNeighbourSelected].id = uint16_t((RXBUFFER[3] << 8) + RXBUFFER[4]);
  neighbours[indexNeighbourSelected].slotIndex = RXBUFFER[5];
  neighbours[indexNeighbourSelected].isLocalized = uint8_t((RXBUFFER[6] >> 7));
  neighbours[indexNeighbourSelected].hoppingDistance = RXBUFFER[6] & 0x7F;

  for (indexGeneral = 0; indexGeneral < MESSAGE_LENGTH; indexGeneral++)
  {
    messageReceivedCharArray[indexGeneral] = uint8_t(RXBUFFER[indexGeneral+7]);
    //printf("RX:%c\n",messageReceivedCharArray[indexGeneral]);
  }

  neighbours[indexNeighbourSelected].RSSI = LT.readPacketRSSI(); // read the received packets RSSI value
  neighbours[indexNeighbourSelected].SNR = LT.readPacketSNR();   // read the received packets SNR value
  neighbours[indexNeighbourSelected].activityCounter = MAXNUMBEROFINACTIVE;

  // Check if there exists any collision (with my neighbour)
  bool assignMeANewSlot = false;
  if (neighbours[indexNeighbourSelected].slotIndex == myInfo.slotIndex)
  {
    assignMeANewSlot = true;
  }

  #ifdef VERBOSE
    printf("Assign me a new slot val: %d\n", assignMeANewSlot);
  #endif 

  if (assignMeANewSlot == true) // if there exists any collision, update the slot
  {
    // identify the available slots
    uint8_t numberOfAvailableSlots, slotCandidate;
    for (slotCandidate = 0; slotCandidate < Nslot; slotCandidate++)
    {
      slotAvailibility[slotCandidate] = true;
      if (neighbours[indexNeighbourSelected].slotIndex == slotCandidate)
      {
        slotAvailibility[slotCandidate] = false;
      }

      for (indexGeneral = 0; indexGeneral < neighbours[indexGeneral].numberOfNeighbours; indexGeneral++)
      {
        if (neighbours[indexNeighbourSelected].neighboursSlot[indexGeneral] == slotCandidate)
        {
          slotAvailibility[slotCandidate] = false;
          break;
        }
      }

      if (slotAvailibility[slotCandidate] == true)
      {
        //printf("available:%d\n", slotCandidate);
        numberOfAvailableSlots++;
      }
    }

    uint8_t indexChosen,cnt=0;
    indexChosen = random(0,numberOfAvailableSlots);

    //printf("Navailable:%d\n", numberOfAvailableSlots);

    uint8_t availableSlotsIndices[numberOfAvailableSlots];
    for (slotCandidate =  0; slotCandidate < Nslot; slotCandidate++)
    {
      if (slotAvailibility[slotCandidate] == true)
      {
        if (cnt == indexChosen)
          {
            #if (fixSlot == 1)
              myInfo.slotIndex = slotDevice;
            #else
              myInfo.slotIndex = slotCandidate;
            #endif
            //printf("Chosen slot:%d\n", slotCandidate);
            break;
          }
        cnt++;
        
      }
    }
  }

  return neighbours[indexNeighbourSelected].slotIndex;
}


void initiator()
{
  if (random(0, 101) <= probabilityOfBeingAnInitiator)
  {
    switch (stateTX)
    {
      case 0:
        stateTX = 1;
        delayMicroseconds(TtxDelay_us);
        doThings_TX_CMD_IDANDPOS();
        break;

      case 1:
        stateTX = 0;
        if (aNewNessageAvailable == true & myInfo.id != 0)
        {
          uint16_t candicateNodeID = 0;
          for (indexGeneral = 0; indexGeneral < cntNeigbours; indexGeneral++)
          {
            if (neighbours[indicesNeighbours[indexGeneral]].hoppingDistance<myInfo.hoppingDistance & neighbours[indicesNeighbours[indexGeneral]].amIListedAsNeigbour==true)
            {
              candicateNodeID = neighbours[indicesNeighbours[indexGeneral]].id;
            }
          } 
          if (candicateNodeID != 0)
          {
            delayMicroseconds(TtxDelay_us);
            doThings_TX_CMD_MESSAGE(candicateNodeID);
          }
          else
          {
            doThings_TX_CMD_IDANDPOS();
          }
        }
        else
        {
          delayMicroseconds(TtxDelay_us);
          doThings_TX_CMD_IDANDPOS();
        }

      default:
        break;
    }  
    #ifdef VERBOSE
      printf("TX: Time elapsed for transmission: %ld us (State: %d)\n", micros()- Tstart,stateTX);
    #endif 
  }
}
responderOutputStructure responder(uint16_t timeOutLoRa)
{
  responderOutputStructure output;
  RXPacketL = LT.receiveIRQ(RXBUFFER, RXBUFFER_SIZE, timeOutLoRa, WAIT_RX);  // wait for a packet to arrive within timeout
  if (RXPacketL > 0) 
  {
    IRQStatus = LT.readIrqStatus(); // read the LoRa device IRQ status register
    addr = (RXBUFFER[0] << 8) + RXBUFFER[1];
    cmd = RXBUFFER[2];

    #ifdef VERBOSE
      printf("RX: ADR[0]:%d ADR[1]:%d CMD:%d\n", RXBUFFER[0], RXBUFFER[1], RXBUFFER[2]);
    #endif        

    if ((addr == ADR_BROADCAST) || (addr == myInfo.id))
    {
      switch (cmd)
      {
      case CMD_IDANDPOS:
        output.slotm = doThings_RX_CMD_IDANDPOS();
        output.adjustTremaining=true;
        break;

      case CMD_MESSAGE:
        output.slotm = doThings_RX_CMD_MESSAGE();
        output.adjustTremaining=true;

        if (myInfo.hoppingDistance!=0)
        {
          aNewNessageAvailable = true;
          messageToBeSent = String(messageReceivedCharArray);
          //printf("RX: A message received to be sent: %s", messageToBeSent);
        }
        else
        {
          aNewNessageAvailable = false;
          //printf("RX: A message received (reference node): %s", String(messageReceivedCharArray));
        }
        break;        

      default:
        #ifdef VERBOSE
            printf("RX: Unknown command\n");
        #endif
        break;
      }
    }
    else
    {
      #ifdef VERBOSE
          printf("RX: It is not a broadcast message or a message intended to me\n");
      #endif
    }
  }
  else
  {
    cmd = 0;
    #ifdef VERBOSE
        printf("RX: Timeout (Nothing is received)\n");
    #endif
  }

  return output;
}

/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
void api()
{
  
  if (!connected) {
    // listen for incoming clients
    client = server.available();
    if (client) {
      printf("Got a client connected!\n ");
      if (client.connected()) {
        printf("succesful connection!\n");
        connected = true;
      } else {
        printf("unsuccesful connection!\n");        
        client.stop();  // close the connection:
      }
    }
  } 
  else {
    if (client.connected()) {
      String command;
      while (client.available() ) { 
        command = client.readStringUntil('&');
      } 
      
      if (command.substring(0,4)=="info")
      {
        responseString = String("myInfo")
              + String(" id ") + String(myInfo.id)
              + String(" slot ") + String(myInfo.slotIndex)
              + String(" hDis ") + String(myInfo.hoppingDistance)
              + String("\n") ;
        responseString.toCharArray(responseCharArray,RESPONSE_LENGTH); client.write(responseCharArray);

        for (indexGeneral = 0; indexGeneral < cntNeigbours; indexGeneral++)
        {
          responseString = String("neighbour")
              + String(" id ") + String(neighbours[indicesNeighbours[indexGeneral]].id)
              + String(" slot ") + String(neighbours[indicesNeighbours[indexGeneral]].slotIndex)
              + String(" hDis ") + String(neighbours[indicesNeighbours[indexGeneral]].hoppingDistance)
              + String(" rssi ") + String(neighbours[indicesNeighbours[indexGeneral]].RSSI)
              + String("\n") ;
          responseString.toCharArray(responseCharArray,RESPONSE_LENGTH); client.write(responseCharArray);                
        }

          responseString = String("messageToBeSent ")
              + messageToBeSent
              + String("\n") ;
          responseString.toCharArray(responseCharArray,RESPONSE_LENGTH); client.write(responseCharArray);     

          responseString = String("messageSent ")
              + String(messageToBeSentCharArray)
              + String("\n") ;
          responseString.toCharArray(responseCharArray,RESPONSE_LENGTH); client.write(responseCharArray);  

          responseString = String("messageReceived ")
              + String(messageReceivedCharArray)
              + String("\n") ;
          responseString.toCharArray(responseCharArray,RESPONSE_LENGTH); client.write(responseCharArray);  

        client.write("done\n");
      }
      else if (command.substring(0,4)==String("trig"))
      {
        printf("Length: %d\n",command.length());
        printf("Received CMD: %s\n",command.substring(0,4));
        messageToBeSent = String(command.substring(5,command.length()));
        aNewNessageAvailable = true;
        //client.write("done\n");
      }

    } 
    else {
      printf("Client has disconnected the TCP-connection\n");
      client.stop();  // close the connection:
      connected = false;
    }
  }  
}
void updateNeighbourStatus()
{


  // Try to eliminate the nodes that are not receiving any message
  for (indexGeneral = 0; indexGeneral < MAXNUMBEROFNEIGBOURS; indexGeneral++)
  {
      if (neighbours[indicesNeighbours[indexGeneral]].activityCounter > 0)
      {
        neighbours[indicesNeighbours[indexGeneral]].activityCounter--;
      }

      if (neighbours[indicesNeighbours[indexGeneral]].activityCounter == 0)
      {
        neighbours[indicesNeighbours[indexGeneral]].id = 0; // remove the node
        neighbours[indicesNeighbours[indexGeneral]].isDistanceMeasured = false;
      }  
  }


  // Count the number of neighbours and get their indices
  cntNeigbours = 0;
  #if isReference == 0 
    myInfo.hoppingDistance = 127;
  #endif
  for (indexGeneral = 0; indexGeneral < MAXNUMBEROFNEIGBOURS; indexGeneral++)
  {
    if (neighbours[indexGeneral].id > 0) // if it exists, update it.
    {
      indicesNeighbours[cntNeigbours] = indexGeneral;
      if ((neighbours[indexGeneral].hoppingDistance!=127) & (neighbours[indexGeneral].hoppingDistance<myInfo.hoppingDistance) & (neighbours[indexGeneral].amIListedAsNeigbour==true))
      {
        myInfo.hoppingDistance = neighbours[indexGeneral].hoppingDistance+1;
      }
      cntNeigbours++;
    }
  }
}
void loop()
{
  // Processing
  Tstart = micros();
  signed long tic0 = micros();
  responderOutputStructure outputResponder;

  cntLoop = cntLoop + 1;
  printf("\nCnt: %d\n", cntLoop);

  updateNeighbourStatus();
  api();
  updateDisplay();
  switchLoRa();  
  
  printf("Time passed (actual processing): %ld us\n", micros()-tic0) ;
  while(Tprocessing_us > (micros()- Tstart)){} // wait for uniform processing time
  printf("Time passed (processing): %ld ms\n", micros()-tic0) ;

  // First One
  Tstart = micros();  
  Tduration = myInfo.slotIndex*Tslot_us;
  Tremaining_us = Tduration - (micros()- Tstart); 
  Tremaining_calc_uint16 = calcTimeOut(Tremaining_us);

    
  while(Tremaining_calc_uint16>0)
  {
    bool receivedAdjustment = false;
    // printf("ID: %d, Tduration: %ld us, Remaining time (before): %ld (%d) us, Expected remaining: %ld us\n", 
    //           myInfo.id, 
    //           Tduration,  
    //           Tremaining_us, 
    //           Tremaining_calc_uint16,
    //           Tslot_us*myInfo.slotIndex+Tprocessing_us-(micros()-tic0));
    
    outputResponder = responder(Tremaining_calc_uint16);     // Responder
    if (outputResponder.adjustTremaining==true)
    {
      if (myInfo.slotIndex > outputResponder.slotm)
        {
          Tremaining_us = (mod(myInfo.slotIndex-outputResponder.slotm-1, Nslot)*(Tslot_us)+((Tslot_us)-Tpacket_us-TtxDelay_us-TrxDelay_us));
          //printf("ID: %d, New Tduration1: %ld us\n", myInfo.id, Tduration);
        }
      else
        {
          Tremaining_us = (mod(myInfo.slotIndex-outputResponder.slotm-1, Nslot)*(Tslot_us)+((Tslot_us)-Tpacket_us-TtxDelay_us-TrxDelay_us)+Tprocessing_us);          
          //printf("ID: %d, New Tduration2: %ld us\n", myInfo.id, Tduration);     
        }
      receivedAdjustment = true;
      printf("received adjustment");
    }
    else
    {
      if (receivedAdjustment == false)
        {
          Tremaining_us = Tduration - (micros()- Tstart);
        }
      else
        {
          Tremaining_us = 0;
        }
    }
    Tremaining_calc_uint16 = calcTimeOut(Tremaining_us);
  };
  printf("Time passed (firstListen): %ld ms\n", micros()-tic0) ;

  // Second One
  Tstart = micros();
  Tduration = (Nslot-myInfo.slotIndex)*Tslot_us;
  
  signed long ticTest = micros();
  initiator();
  // printf("Initiator duration: %ld ms\n", micros()-ticTest);
  // printf("After t0 duration: %ld ms\n", micros()-tic0) ;
  
  Tremaining_us = Tduration - (micros()- Tstart);   
  Tremaining_calc_uint16 = calcTimeOut(Tremaining_us);

  while(Tremaining_calc_uint16>0)
  {
    bool receivedAdjustment = false;
    // printf("ID: %d, Tduration: %ld us, Remaining time (after): %ld (%d) us, Expected remaining: %ld us\n", 
    //           myInfo.id, 
    //           Tduration,  
    //           Tremaining_us, 
    //           Tremaining_calc_uint16,
    //           Tperiod_us+Tprocessing_us-(micros()-tic0));
    // signed long ticTest = micros();              
    outputResponder = responder(Tremaining_calc_uint16);     // Responder
    // printf("Responder duration: %ld ms\n", micros()-ticTest);
    if (outputResponder.adjustTremaining==true)
    {
      Tremaining_us = ((Nslot-outputResponder.slotm-1)*Tslot_us+((Tslot_us)-Tpacket_us-TtxDelay_us-TrxDelay_us));  
      //printf("ID: %d, New Tduration3: %ld us\n", myInfo.id, Tduration);
      receivedAdjustment = true;
    }
    else
    {
      if (receivedAdjustment == false)
        {
          Tremaining_us = Tduration - (micros()- Tstart);
        }
      else
        {
          Tremaining_us = 0;
        }
    }
    Tremaining_calc_uint16 = calcTimeOut(Tremaining_us);
  };
  
  printf("Time passed (final): %ld ms\n", micros()-tic0) ;
}
void setup()
{
  printf("This is the setup phase\n");
  // When the power is turned on, a delay is required.
  SPI.begin(RADIO_SCLK_PIN, RADIO_MISO_PIN, RADIO_MOSI_PIN);
  Wire.begin(I2C_SDA, I2C_SCL);
  if (LT.begin(NSS, NRESET, RFBUSY, DIO1, RX_EN, TX_EN, LORA_DEVICE))
  {
    printf("LoRa Device found\n");
  }
  else
  {
    printf("No device responding\n");
  }


  myInfo.id = deviceID;//random(1, 65536);
  myInfo.posX.number = random(-500, 500);
  myInfo.posY.number = random(-500, 500);
  myInfo.posZ.number = random(-500, 500);
  #if (fixSlot == 1)
    myInfo.slotIndex = slotDevice;
  #else
    myInfo.slotIndex = random(0, Nslot);
  #endif

  disp.begin();
  disp.setFont(u8x8_font_chroma48medium8_r);
  updateDisplay();

  //WiFi.useStaticBuffers(true);
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, pass);


  // Set your Static IP address
  IPAddress local_IP(192, 168, 1, IPlastDigit);
  IPAddress gateway(192, 168, 1, 1);

  // IPAddress local_IP(172, 20, 10, IPlastDigit);
  // IPAddress gateway(172, 20, 10, 1);

  IPAddress subnet(255, 255, 255, 0);

  if (!WiFi.config(local_IP, gateway, subnet)) {
    printf("Wait for WiFi config\n");
  }

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    printf("Trying to connect to the Wi-Fi!\n");
    server.begin();
  }  


  setupDevice(); // configure frequency and LoRa settings

  delay(1000);
}
