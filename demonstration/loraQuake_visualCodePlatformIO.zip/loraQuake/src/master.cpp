/*****************************************************************************************************
  Programs for Arduino - Copyright of the author Stuart Robinson - 16/03/20

  This program is supplied as is, it is up to the user of the program to decide if the program is
  suitable for the intended purpose and free from errors.
*******************************************************************************************************/

#include <SPI.h>
#include <Wire.h>
#include <U8g2lib.h>
#include <SX1280_alphan.h>
#include "settings.h"

U8G2_SSD1306_128X64_NONAME_F_HW_I2C *u8g2 = nullptr;
SX128XLT LT;  //create a library class instance called LT

uint16_t rangeing_errors, rangeings_valid;
uint16_t IrqStatus;
uint32_t endwaitmS, startrangingmS;
float range_result_sum, range_result_average, rangeing_results;
double distanceRAW, distanceBIASED;
bool ranging_error;
int32_t range_result;
int16_t RangingRSSI;


void loop() {
  //printf("This is the loop phase\n");
  //  LT.transmitRanging(RangingAddress, TXtimeoutmS, RangingTXPower, WAIT_TX);

  LT.transmitRanging(ADR_BROADCAST, 1000, TXPower, WAIT_TX);

  IrqStatus = LT.readIrqStatus();
  
  if (IrqStatus & IRQ_RANGING_MASTER_RESULT_VALID) {
    range_result = LT.getRangingResultRegValue(RANGING_RESULT_RAW);
    distanceRAW = LT.getRangingDistance(RANGING_RESULT_RAW, range_result, distance_adjustment);
    distanceBIASED = LT.getRangingDistance(RANGING_RESULT_DEBIASED, range_result, distance_adjustment);
    printf("Raw:%d, Distance (Raw): %f, Distance (Biased):%f\n", range_result, distanceRAW, distanceBIASED);
  } 
  
  if (IrqStatus & IRQ_RANGING_MASTER_RESULT_TIMEOUT){
    printf("Master timeout\n");
  }

  delay(100);  
}


void setup() {
  printf("This is the setup phase\n");
  // When the power is turned on, a delay is required.
  SPI.begin(RADIO_SCLK_PIN, RADIO_MISO_PIN, RADIO_MOSI_PIN);
  
  if (LT.begin(NSS, NRESET, RFBUSY, DIO1, RX_EN, TX_EN, LORA_DEVICE)) {
    printf("LoRa Device found\n");
  } else {
    printf("No device responding\n");
  }

  Wire.begin(I2C_SDA, I2C_SCL);
  Wire.beginTransmission(0x3C);
  if (Wire.endTransmission() == 0) {
    u8g2 = new U8G2_SSD1306_128X64_NONAME_F_HW_I2C(U8G2_R0, U8X8_PIN_NONE);
    u8g2->begin();
    u8g2->clearBuffer();
    u8g2->setFlipMode(0);
    u8g2->setFontMode(1);  // Transparent
    u8g2->setDrawColor(1);
    u8g2->setFontDirection(0);
    u8g2->firstPage();
    do {
      u8g2->setFont(u8g2_font_inb19_mr);
      u8g2->drawStr(0, 30, "LoRa");
      u8g2->setFont(u8g2_font_inb19_mf);
      u8g2->drawStr(0, 60, "Master");
    } while (u8g2->nextPage());
    u8g2->sendBuffer();
    u8g2->setFont(u8g2_font_fur11_tf);
    delay(3000);
  }
  delay(2000);

  LT.setupRanging(frequency, offset, spreadingFactor, bandwidth, codeRate, ADR_BROADCAST, RANGING_MASTER);
  LT.setRangingCalibration(calibration);               //override automatic lookup of calibration value from library table

}


