/*****************************************************************************************************
  Programs for LoRaQuake - Copyright of the author Alphan Sahin - 15/06/2023

  This program is supplied as is, it is up to the user of the program to decide if the program is
  suitable for the intended purpose and free from errors.
*******************************************************************************************************/
//#define VERBOSE 
//*******  Setup hardware pin definitions here ! ***************
#define I2C_SDA 18
#define I2C_SCL 17
#define RADIO_SCLK_PIN 5
#define RADIO_MISO_PIN 3
#define RADIO_MOSI_PIN 6

#define NSS 7
#define RFBUSY 36
#define NRESET 8
#define LED1 37
#define DIO1 9
#define DIO2 33
#define DIO3 34
#define RX_EN 21
#define TX_EN 10

#define LORA_DEVICE DEVICE_SX1280 // we need to define the device we are using
#define RAMP_TIME RADIO_RAMP_02_US

//*******  Setup LoRa Parameters Here ! ***************
// LoRa Modem Parameters
const uint32_t frequency = 2500000000;    // frequency of transmissions in hz
const int32_t offset = 0;                 // offset frequency in hz for calibration purposes
const uint8_t bandwidth = LORA_BW_0800;   // LoRa bandwidth
const uint8_t spreadingFactor = LORA_SF10; // LoRa spreading factor
const uint8_t codeRate = LORA_CR_4_5;  // LoRa coding rate
const int8_t TXPower = 13;          // Transmit power used
const float distance_adjustment = 1.0000;              //adjustment factor to calculated distance
const uint16_t calibration = 12990; // Manual Ranging calibrarion value (13710)
const uint16_t rangingTimeoutTX = 0;
const uint16_t rangingTimeoutRX = 300;
const uint16_t communicationTimeoutTX = 0;

const long periodInitiatorResponder = (500)*1000;
const long durationOffset =  200;

const long Tperiod_ms = 200;
const long Tprocessing_ms = 100;
const long Tslot_ms = 25;
const long Tpacket_ms = 4.0;
const long TtxDelay_ms = 5;
const long TrxDelay_ms = 1;
const long Nslot = Tperiod_ms/Tslot_ms;

const long Tperiod_us = Tperiod_ms*1000;
const long Tprocessing_us = Tprocessing_ms*1000;
const long Tslot_us = Tslot_ms*1000;
const long Tpacket_us = Tpacket_ms*1000;
const long TtxDelay_us = TtxDelay_ms*1000;
const long TrxDelay_us = TrxDelay_ms*1000;

// LoRaQuake Modem Parameters
const uint8_t periodBaseVar=PERIODBASE_01_MS;
//const uint8_t periodBaseVar=PERIODBASE_15_US;
#define RESPONSE_LENGTH 50
#define MESSAGE_LENGTH 24
#define RXBUFFER_SIZE 255
#define TXBUFFER_SIZE 255
#define MAXNUMBEROFNEIGBOURS 10
#define MAXNUMBEROFINACTIVE 20
#define SERVERPORTVAL 23
#define SLOTDEVICE1 0

#define probabilityOfBeingAnInitiator 80

typedef union
{
  float number;
  uint8_t bytes[4];
} floatunionType;

struct responderOutputStructure
{
  uint8_t slotm = 255;
  bool adjustTremaining = false;
};

struct neighbourStructure
{
  uint16_t id = 0;
  uint8_t slotIndex;
  bool isLocalized = 0;
  uint8_t hoppingDistance = 0x7F; // 0x7F: unknown distance, 0x00: reference node
  floatunionType posX;
  floatunionType posY;
  floatunionType posZ;

  uint8_t numberOfNeighbours;
  uint16_t neighboursId[MAXNUMBEROFNEIGBOURS];
  uint8_t neighboursSlot[MAXNUMBEROFNEIGBOURS];
  uint8_t neighboursHoppingDistance[MAXNUMBEROFNEIGBOURS];
  bool neighboursIsLocalized[MAXNUMBEROFNEIGBOURS];
  floatunionType neighboursPosX[MAXNUMBEROFNEIGBOURS];
  floatunionType neighboursPosY[MAXNUMBEROFNEIGBOURS];
  floatunionType neighboursPosZ[MAXNUMBEROFNEIGBOURS];
  bool amIListedAsNeigbour = false;

  // Measurement related
  floatunionType distance;
  int16_t RSSI = 0;
  int8_t SNR = 0;
  bool isDistanceMeasured = false;
  uint8_t activityCounter = 0;
};

struct myInfoStructure
{
  uint16_t id = 0;
  uint8_t slotIndex;
  uint8_t isLocalized = isReference;
  #if isReference == 1
    uint8_t hoppingDistance = 0x00; // 0x7F: unknown distance, 0x00: reference node
  #else
    uint8_t hoppingDistance = 0x7F; // 0x7F: unknown distance, 0x00: reference node  
  #endif
  floatunionType posX;
  floatunionType posY;
  floatunionType posZ;
};

const uint16_t ADR_BROADCAST = 0x0000;
const uint8_t CMD_IDANDPOS = 0x00;
const uint8_t CMD_START_RANGING = 0x01;
const uint8_t CMD_MESSAGE = 0x02;

int mod( int x, int y ){
  return x<0 ? ((x+1)%y)+y-1 : x%y;
}


uint16_t calcTimeOut(signed long Tremaining){
  uint16_t timeOut=0;
  if (Tremaining>0)
  {    
    switch (periodBaseVar)
      {
      case PERIODBASE_01_MS:
        timeOut = uint16_t(round(double(Tremaining)/1000));
        //printf("1ms,Tremaining: %ld, TimeoutDivision: %f, Timeout:%d\n", Tremaining, round(double(Tremaining)/1000),  timeOut);
        break;

      case PERIODBASE_15_US:
        timeOut = uint16_t(round(double(Tremaining)/15.625));
        //printf("15.625us,Tremaining: %ld, TimeoutDivision: %f, Timeout:%d\n", Tremaining, round(double(Tremaining)/15.625),  timeOut);
        break;      
      
      default:
        break;
      }    
  }
  return timeOut;
  
}


